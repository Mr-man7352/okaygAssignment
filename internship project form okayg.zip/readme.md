## https://mr-man7352.github.io/okaygAssignment/

👆 check the assignment here

only the search functionality is left
